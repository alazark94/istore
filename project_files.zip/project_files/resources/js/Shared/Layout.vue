<template>
<section>
    <slot></slot>
</section>
</template>

<script>
export default {
    name: "Layout"
}
</script>

<style scoped>

</style>
