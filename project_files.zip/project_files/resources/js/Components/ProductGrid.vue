<template>

<div class="grid grid-cols-3 gap-4">
    <Product @visible="$emit('clicked')" v-for="product in props.products" :product="product"/>
</div>
</template>

<script>
export default {
    name: "ProductGrid",

}
</script>

<script setup>
import Product from "@/Components/Product";
import ThePopUp from "@/Components/ThePopUp";
import {defineProps} from "vue";

let props = defineProps({
    products: Array
});
</script>

<style scoped>

</style>
